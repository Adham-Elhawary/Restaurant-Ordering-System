﻿namespace projectRest.Models
{
    public class Employees
    {
    }
}
