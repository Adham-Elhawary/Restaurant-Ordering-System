﻿using Models;
using System;

namespace projectRest.Models
{
    public class Orders
    {
        public int Order_Id { get; set; }

        public DateTime Order_Date { get; set; }

        public int Customer_Id { get; set; }

        public Customer Customer { get; set; }

        public int employee_Id { get; set; }

        public Employees employee { get; set; }

        public float Total { get; set; }


    }
}
