﻿using Models;

namespace projectRest.Models
{
    public class Reserved
    {
        public int Id { get; set; }

        public int Table_Id { get; set; }

        public Tables Table { get; set; }

        public int Customer_Id { get; set; }

        public Customer Customer { get; set; }

        public DateTime Reserved_Date { get; set; }

        public DateTime Reserved_Time { get; set; }
    }
}
