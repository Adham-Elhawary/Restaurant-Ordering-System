﻿namespace projectRest.Models
{
    public class Order_Product
    {
        public int Id { get; set; }
        public int Order_Id { get; set; }
        public Orders Order { get; set; }
        public int Product_Id { get; set; }
        public Products Product { get; set; }
        public int Quantity { get; set; }
        public float Price { get; set; }
    }
}
