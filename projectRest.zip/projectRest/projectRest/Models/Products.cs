﻿namespace projectRest.Models
{
    public class Products
    {
    }
}
