﻿namespace projectRest.Models
{
    public class Tables
    {
        public int Id { get; set; }

        public bool IsAvailable { get; set; }
    }
}
