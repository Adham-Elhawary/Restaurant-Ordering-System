﻿using Models;

namespace projectRest.Models
{
    public class Ratings
    {
        public int Id { get; set; }

        public int Order_Id { get; set; }
        public Orders Order { get; set; }

        public int Customer_Id { get; set; }

        public Customer Customer { get; set; }

        public string comment { get; set; }
    }
}
